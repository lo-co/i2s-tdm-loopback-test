README for GRB-35099_E3.zip

Company Part Number: 170-35099 REV E3

Date: Wed, 08 Jan 2020 22:42:59 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : Emily Tong
Work Phone          : 512-895-6068
Email               : emily.tong@nxp.com

CAD Manager
===========
Company Contact     : Daniel Kruczek
Work Phone          : 512-895-6081
Email               : daniel.kruczek@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Peter Naehrig
Work Phone          : 512-895-6196
Email               : peter.naehrig@nxp.com

Product Engineer
================
Company Contact     : Clyde Lovelace
Work Phone          : 512-895-6112
Email               : clyde.lovelace@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HardwareSolutionsCoE-PCB@NXP1.onmicrosoft.com
